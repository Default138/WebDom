<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once(__DIR__ . "/../../model/Tarefa.php");
require_once(__DIR__ . "/../../model/Prioridade.php");
require_once(__DIR__ . "/../../model/Tema.php");
require_once(__DIR__ . "/../../controller/TarefaController.php");

$erros = [];
$tarefa = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titulo = trim($_POST['titulo'] ?? '') ?: null;
    $descricao = trim($_POST['descricao'] ?? '') ?: null;
    $data_entrega = trim($_POST['data_entrega'] ?? '') ?: null;
    $prioridade_id = is_numeric($_POST['prioridade_id'] ?? null) ? (int)$_POST['prioridade_id'] : null;
    $tema_id = is_numeric($_POST['tema_id'] ?? null) ? (int)$_POST['tema_id'] : null;

    $tarefa = new Tarefa();
    $tarefa->setTitulo($titulo);
    $tarefa->setDescricao($descricao);
    $tarefa->setDataEntrega($data_entrega);

    $prioridade = new Prioridade();
    $prioridade->setId($prioridade_id);
    $tarefa->setPrioridade($prioridade);

    $tema = new Tema();
    $tema->setId($tema_id);
    $tarefa->setTema($tema);

    $controller = new TarefaController();
    $erros = $controller->inserir($tarefa);

    if (empty($erros)) {
        header("Location: listar.php?msg=Tarefa inserida com sucesso!");
        exit;
    }
}

require_once(__DIR__ . "/../../controller/PrioridadeController.php");
require_once(__DIR__ . "/../../controller/TemaController.php");

$prioridadeCont = new PrioridadeController();
$temasCont = new TemaController();
$prioridades = $prioridadeCont->listar();
$temas = $temasCont->listar();

// 1. Inclui o cabeçalho
require_once(__DIR__ . "/../include/header.php");

// 2. Inclui o formulário (recebe as variáveis $tarefa, $erros, $prioridades e $temas)
require_once(__DIR__ . "/form.php");

// 3. Inclui o rodapé
require_once(__DIR__ . "/../include/footer.php");
?>