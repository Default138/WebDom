<?php
if (!defined('BASE_URL')) {
    define('BASE_URL', '/Camargo/Ling_Prog/TrabalhoCrud/');
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Gestão de Atividades</title>

    <!-- Bootstrap 5 CSS (CDN - Carrega perfeitamente em todas as pastas) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons (CDN) -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body>
    <main>
        <?php require_once __DIR__ . '/menu.php'; ?>